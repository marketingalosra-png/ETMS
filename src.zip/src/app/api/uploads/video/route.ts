import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { type NextRequest } from "next/server";
import { json, withApiGuard } from "@/lib/api";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  return withApiGuard(request, async () => {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return json({ error: "Video file is required" }, { status: 422 });
    if (!file.type.startsWith("video/")) return json({ error: "Only video files are allowed" }, { status: 422 });

    const extension = path.extname(file.name) || ".mp4";
    const fileName = `${randomUUID()}${extension}`;
    const uploadDir = path.join(process.cwd(), "public", "uploads");
    await mkdir(uploadDir, { recursive: true });
    await writeFile(path.join(uploadDir, fileName), Buffer.from(await file.arrayBuffer()));

    return json({
      url: `/uploads/${fileName}`,
      fileName,
      mimeType: file.type,
      sizeBytes: file.size
    }, { status: 201 });
  }, { adminOnly: true });
}
