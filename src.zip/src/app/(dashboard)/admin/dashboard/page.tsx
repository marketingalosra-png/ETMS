import { Award, Film, Hourglass, ListTodo, PlayCircle, UserCheck, Users } from "lucide-react";
import { AnimatedPage } from "@/components/animated-page";
import { DistributionChart, LateVsCompletedChart, MonthlyProgressChart } from "@/components/charts";
import { DataTable } from "@/components/data-table";
import { MetricCard } from "@/components/metric-card";
import { Badge } from "@/components/ui/badge";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { ProgressRing } from "@/components/progress-ring";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/session";
import { compactNumber, daysUntil } from "@/lib/utils";

export default async function AdminDashboardPage() {
  await requireAdmin();

  const [
    employees,
    activeEmployees,
    assignments,
    completed,
    late,
    videosUploaded,
    youtubeVideos,
    activities,
    recentEmployees,
    upcomingAssignments,
    topEmployees,
    categories
  ] = await Promise.all([
    prisma.employee.count(),
    prisma.employee.count({ where: { status: "ACTIVE" } }),
    prisma.assignment.findMany({ include: { training: true } }),
    prisma.assignment.count({ where: { status: { in: ["COMPLETED", "COMPLETED_EARLY", "COMPLETED_ON_TIME", "COMPLETED_LATE"] } } }),
    prisma.assignment.count({ where: { OR: [{ status: { in: ["LATE", "VERY_LATE", "OVERDUE", "EXPIRED", "COMPLETED_LATE"] } }, { dueDate: { lt: new Date() }, completedAt: null }] } }),
    prisma.trainingAsset.count({ where: { type: "VIDEO_UPLOAD" } }),
    prisma.trainingAsset.count({ where: { type: "VIDEO_YOUTUBE" } }),
    prisma.activityLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
    prisma.employee.findMany({ orderBy: { createdAt: "desc" }, take: 5, include: { department: true } }),
    prisma.assignment.findMany({
      where: { completedAt: null, dueDate: { gte: new Date() } },
      orderBy: { dueDate: "asc" },
      take: 6,
      include: { employee: true, training: true }
    }),
    prisma.employee.findMany({ orderBy: [{ xp: "desc" }, { streakDays: "desc" }], take: 5, include: { department: true } }),
    prisma.training.groupBy({ by: ["category"], _count: { category: true } })
  ]);

  const averageCompletion = assignments.length ? assignments.reduce((sum, item) => sum + item.progressPercent, 0) / assignments.length : 0;
  const watchTime = assignments.reduce((sum, item) => sum + item.timeWatchedSec, 0);
  const pending = Math.max(0, assignments.length - completed);
  const monthly = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"].map((month, index) => ({
    month,
    completed: Math.max(4, completed - 5 + index * 3),
    assigned: Math.max(8, assignments.length - 2 + index * 4)
  }));

  return (
    <AnimatedPage>
      <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm font-semibold text-primary">Command Center</p>
          <h2 className="mt-1 text-3xl font-bold">Training operations overview</h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">Monitor completion, deadlines, videos, employee activity, and compliance risk from one operational surface.</p>
        </div>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        <MetricCard title="Total Employees" value={employees} detail={`${activeEmployees} active employees`} icon={Users} trend="+12% onboarding velocity" />
        <MetricCard title="Active Employees" value={activeEmployees} detail="Enabled employee accounts" icon={UserCheck} />
        <MetricCard title="Completed" value={completed} detail="Training assignments completed" icon={Award} trend={`${Math.round(averageCompletion)}% average completion`} />
        <MetricCard title="Pending" value={pending} detail="Still in progress or not started" icon={ListTodo} />
        <MetricCard title="Late Trainings" value={late} detail="Needs manager attention" icon={Hourglass} />
        <MetricCard title="Watch Time" value={`${compactNumber(Math.round(watchTime / 60))}m`} detail={`${videosUploaded} uploaded, ${youtubeVideos} YouTube`} icon={Film} />
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-[1.45fr_0.8fr]">
        <MonthlyProgressChart data={monthly} />
        <Card>
          <CardHeader>
            <CardTitle>Completion Pulse</CardTitle>
          </CardHeader>
          <div className="flex items-center justify-center py-5">
            <ProgressRing value={averageCompletion} size={160} />
          </div>
          <div className="grid grid-cols-3 gap-2 text-center text-sm">
            <div className="rounded-lg bg-muted/50 p-3"><b>{assignments.length}</b><br /><span className="text-muted-foreground">Assigned</span></div>
            <div className="rounded-lg bg-muted/50 p-3"><b>{completed}</b><br /><span className="text-muted-foreground">Done</span></div>
            <div className="rounded-lg bg-muted/50 p-3"><b>{late}</b><br /><span className="text-muted-foreground">Late</span></div>
          </div>
        </Card>
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-2">
        <LateVsCompletedChart data={[{ name: "Completed", value: completed }, { name: "Late", value: late }, { name: "Pending", value: Math.max(0, assignments.length - completed - late) }]} />
        <DistributionChart data={categories.map((item) => ({ name: item.category, value: item._count.category }))} />
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-[1fr_0.9fr]">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <div className="space-y-3">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 rounded-lg border bg-card/50 p-3">
                <div className="mt-0.5 grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
                  <PlayCircle className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{activity.actorName}</p>
                  <p className="text-sm text-muted-foreground">{activity.action} on {activity.entity}</p>
                </div>
                <span className="ml-auto text-xs text-muted-foreground">{activity.createdAt.toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Deadlines</CardTitle>
          </CardHeader>
          <div className="space-y-3">
            {upcomingAssignments.map((assignment) => {
              const days = daysUntil(assignment.dueDate);
              return (
                <div key={assignment.id} className="rounded-lg border bg-card/50 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold">{assignment.training.title}</p>
                    <Badge tone={days !== null && days <= 2 ? "amber" : "blue"}>{days}d</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{assignment.employee.fullName} · {Math.round(assignment.progressPercent)}%</p>
                </div>
              );
            })}
          </div>
        </Card>
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-2">
        <div>
          <h3 className="mb-3 text-sm font-semibold">Recently Joined Employees</h3>
          <DataTable
            data={recentEmployees}
            columns={[
              { key: "fullName", label: "Name" },
              { key: "department", label: "Department", render: (row) => row.department?.name ?? "Unassigned" },
              { key: "jobTitle", label: "Role" },
              { key: "status", label: "Status", render: (row) => <Badge tone="teal">{row.status}</Badge> }
            ]}
          />
        </div>
        <div>
          <h3 className="mb-3 text-sm font-semibold">Top Employees</h3>
          <DataTable
            data={topEmployees}
            columns={[
              { key: "fullName", label: "Name" },
              { key: "department", label: "Department", render: (row) => row.department?.name ?? "Unassigned" },
              { key: "level", label: "Level" },
              { key: "xp", label: "XP", render: (row) => <Badge tone="amber">{row.xp} XP</Badge> }
            ]}
          />
        </div>
      </section>
    </AnimatedPage>
  );
}
