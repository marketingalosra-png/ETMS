import { AnimatedPage } from "@/components/animated-page";
import { TrainingManager } from "@/components/admin/training-manager";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/session";

export default async function TrainingsPage() {
  await requireAdmin();
  const trainings = await prisma.training.findMany({
    include: { assets: { orderBy: { sortOrder: "asc" } }, assignments: true },
    orderBy: { createdAt: "desc" }
  });
  return (
    <AnimatedPage>
      <div className="mb-5">
        <p className="text-sm font-semibold text-primary">Courses</p>
        <h2 className="mt-1 text-3xl font-bold">Training Management</h2>
        <p className="mt-2 text-muted-foreground">Create clean training courses with thumbnails, due dates, and uploaded, YouTube, or external videos.</p>
      </div>
      <TrainingManager initialTrainings={trainings} />
    </AnimatedPage>
  );
}
