"use client";

import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

export function MetricCard({ title, value, detail, icon: Icon, trend }: { title: string; value: string | number; detail: string; icon: LucideIcon; trend?: string }) {
  return (
    <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300, damping: 24 }}>
      <Card className="relative overflow-hidden">
        <div className="absolute right-0 top-0 h-24 w-24 rounded-bl-full bg-primary/10" />
        <div className="relative flex items-start justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">{title}</p>
            <div className="mt-3 text-3xl font-bold">{value}</div>
            <p className="mt-2 text-sm text-muted-foreground">{detail}</p>
          </div>
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
            <Icon className="h-5 w-5" />
          </div>
        </div>
        {trend ? <div className="mt-4 text-xs font-semibold text-teal-600 dark:text-teal-300">{trend}</div> : null}
      </Card>
    </motion.div>
  );
}
