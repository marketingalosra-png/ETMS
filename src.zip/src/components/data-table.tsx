import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function DataTable<T>({
  columns,
  data,
  empty
}: {
  columns: Array<{ key: keyof T | string; label: string; render?: (row: T) => ReactNode; className?: string }>;
  data: T[];
  empty?: string;
}) {
  return (
    <Card className="overflow-hidden p-0">
      <div className="overflow-x-auto scrollbar-thin">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b bg-muted/40 text-xs uppercase tracking-[0.14em] text-muted-foreground">
            <tr>
              {columns.map((column) => (
                <th key={String(column.key)} className={cn("px-4 py-3 font-semibold", column.className)}>{column.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td className="px-4 py-10 text-center text-muted-foreground" colSpan={columns.length}>{empty ?? "No records found"}</td>
              </tr>
            ) : (
              data.map((row, index) => (
                <tr key={index} className="border-b last:border-b-0 hover:bg-muted/35">
                  {columns.map((column) => (
                    <td key={String(column.key)} className={cn("px-4 py-3 align-middle", column.className)}>
                      {column.render ? column.render(row) : String((row as Record<string, unknown>)[String(column.key)] ?? "")}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
