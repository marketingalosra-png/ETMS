"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import type { Department, Employee, User } from "@prisma/client";
import { Edit3, Search, Trash2, UserMinus, UserPlus } from "lucide-react";
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/data-table";
import { employeeSchema } from "@/lib/validation";

type EmployeeRow = Employee & { user: User; department: Department | null; assignments: Array<{ id: string; status: string }> };
type FormInput = z.infer<typeof employeeSchema>;

const defaults: FormInput = {
  fullName: "",
  employeeCode: "",
  email: "",
  departmentId: "",
  jobTitle: "",
  manager: "",
  phone: "",
  nationalId: "",
  joiningDate: new Date(),
  birthDate: null,
  gender: "UNDISCLOSED",
  address: "",
  emergencyContact: "",
  notes: "",
  photoUrl: "",
  status: "ACTIVE"
};

export function EmployeeManager({ initialEmployees, departments }: { initialEmployees: EmployeeRow[]; departments: Department[] }) {
  const [employees, setEmployees] = useState(initialEmployees);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<EmployeeRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<EmployeeRow | null>(null);
  const form = useForm<FormInput>({ resolver: zodResolver(employeeSchema), defaultValues: defaults });

  const filtered = useMemo(() => {
    const term = search.toLowerCase();
    return employees.filter((employee) =>
      [employee.fullName, employee.employeeCode, employee.user.email, employee.department?.name].some((value) => value?.toLowerCase().includes(term))
    );
  }, [employees, search]);

  function edit(employee: EmployeeRow) {
    setEditing(employee);
    form.reset({
      fullName: employee.fullName,
      employeeCode: employee.employeeCode,
      email: employee.user.email ?? "",
      departmentId: employee.departmentId ?? "",
      jobTitle: employee.jobTitle,
      manager: employee.manager ?? "",
      phone: employee.phone ?? "",
      nationalId: employee.nationalId ?? "",
      joiningDate: employee.joiningDate,
      birthDate: employee.birthDate,
      gender: employee.gender,
      address: employee.address ?? "",
      emergencyContact: employee.emergencyContact ?? "",
      notes: employee.notes ?? "",
      photoUrl: employee.photoUrl ?? "",
      status: employee.status
    });
  }

  async function save(input: FormInput) {
    const url = editing ? `/api/employees/${editing.id}` : "/api/employees";
    const response = await fetch(url, {
      method: editing ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input)
    });
    if (!response.ok) {
      toast.error("Employee save failed");
      return;
    }
    const payload = await response.json() as { employee: EmployeeRow };
    setEmployees((current) => editing ? current.map((item) => item.id === payload.employee.id ? { ...payload.employee, assignments: item.assignments } : item) : [payload.employee, ...current]);
    form.reset(defaults);
    setEditing(null);
    toast.success(editing ? "Employee updated" : "Employee added");
  }

  async function disable(employee: EmployeeRow) {
    const response = await fetch(`/api/employees/${employee.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: employee.status === "DEACTIVATED" ? "ACTIVE" : "DEACTIVATED" })
    });
    if (!response.ok) return toast.error("Status update failed");
    const payload = await response.json() as { employee: EmployeeRow };
    setEmployees((current) => current.map((item) => item.id === payload.employee.id ? { ...item, ...payload.employee } : item));
    toast.success(employee.status === "DEACTIVATED" ? "Employee activated" : "Employee disabled");
  }

  async function remove() {
    if (!deleteTarget) return;
    const response = await fetch(`/api/employees/${deleteTarget.id}`, { method: "DELETE" });
    if (!response.ok) return toast.error("Delete failed");
    setEmployees((current) => current.filter((item) => item.id !== deleteTarget.id));
    setDeleteTarget(null);
    toast.success("Employee deleted");
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[0.85fr_1.4fr]">
      <Card>
        <CardHeader>
          <CardTitle>{editing ? "Edit Employee" : "Add Employee"}</CardTitle>
        </CardHeader>
        <form className="grid gap-3" onSubmit={form.handleSubmit(save)}>
          <Input placeholder="Full name" {...form.register("fullName")} />
          <Input placeholder="Employee ID" {...form.register("employeeCode")} />
          <Input placeholder="Email" type="email" {...form.register("email")} />
          <select className="h-10 rounded-lg border bg-card px-3 text-sm" {...form.register("departmentId")}>
            <option value="">No department</option>
            {departments.map((department) => <option key={department.id} value={department.id}>{department.name}</option>)}
          </select>
          <Input placeholder="Job title" {...form.register("jobTitle")} />
          <Input placeholder="Phone" {...form.register("phone")} />
          <Input placeholder="Profile photo URL" {...form.register("photoUrl")} />
          <Input type="date" {...form.register("joiningDate", { valueAsDate: true })} />
          <div className="flex gap-2">
            <Button type="submit" className="flex-1"><UserPlus className="h-4 w-4" />{editing ? "Save" : "Add"}</Button>
            {editing ? <Button type="button" variant="secondary" onClick={() => { setEditing(null); form.reset(defaults); }}>Cancel</Button> : null}
          </div>
        </form>
      </Card>

      <div>
        <div className="mb-3 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9" placeholder="Search employees..." value={search} onChange={(event) => setSearch(event.target.value)} />
          </div>
        </div>
        <DataTable
          data={filtered}
          columns={[
            { key: "fullName", label: "Employee", render: (row) => <div><p className="font-semibold">{row.fullName}</p><p className="text-xs text-muted-foreground">{row.employeeCode}</p></div> },
            { key: "department", label: "Department", render: (row) => row.department?.name ?? "Unassigned" },
            { key: "jobTitle", label: "Job Title" },
            { key: "email", label: "Email", render: (row) => row.user.email },
            { key: "status", label: "Status", render: (row) => <Badge tone={row.status === "ACTIVE" ? "teal" : "red"}>{row.status}</Badge> },
            {
              key: "actions",
              label: "",
              render: (row) => (
                <div className="flex justify-end gap-1">
                  <Button variant="ghost" className="h-9 w-9 px-0" onClick={() => edit(row)}><Edit3 className="h-4 w-4" /></Button>
                  <Button variant="ghost" className="h-9 w-9 px-0" onClick={() => disable(row)}><UserMinus className="h-4 w-4" /></Button>
                  <Button variant="ghost" className="h-9 w-9 px-0" onClick={() => setDeleteTarget(row)}><Trash2 className="h-4 w-4" /></Button>
                </div>
              )
            }
          ]}
        />
      </div>
      <ConfirmDialog open={Boolean(deleteTarget)} title="Delete employee?" description="This removes the employee, their login, assignments, and progress history." onClose={() => setDeleteTarget(null)} onConfirm={remove} />
    </div>
  );
}
