"use client";

import type { Assignment, Department, Employee, Training, User } from "@prisma/client";
import { Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { DataTable } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type EmployeeRow = Employee & { user: User; department: Department | null };
type AssignmentRow = Assignment & { employee: EmployeeRow; training: Training };

export function AssignmentManager({
  employees,
  trainings,
  initialAssignments
}: {
  employees: EmployeeRow[];
  trainings: Training[];
  initialAssignments: AssignmentRow[];
}) {
  const [employeeIds, setEmployeeIds] = useState<string[]>([]);
  const [trainingIds, setTrainingIds] = useState<string[]>([]);
  const [dueDate, setDueDate] = useState("");
  const [assignments, setAssignments] = useState(initialAssignments);

  function toggle(list: string[], value: string, setter: (next: string[]) => void) {
    setter(list.includes(value) ? list.filter((item) => item !== value) : [...list, value]);
  }

  async function assign() {
    if (!employeeIds.length || !trainingIds.length) {
      toast.error("Choose at least one employee and one training");
      return;
    }
    const response = await fetch("/api/assignments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ employeeIds, trainingIds, everyone: false, dueDate: dueDate || null })
    });
    if (!response.ok) return toast.error("Assignment failed");
    const fresh = await fetch("/api/assignments").then((res) => res.json()) as { assignments: AssignmentRow[] };
    setAssignments(fresh.assignments);
    setEmployeeIds([]);
    setTrainingIds([]);
    setDueDate("");
    toast.success("Training assigned");
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[0.95fr_1.35fr]">
      <Card>
        <CardHeader>
          <CardTitle>Assign Trainings</CardTitle>
        </CardHeader>
        <div className="space-y-5">
          <section>
            <p className="mb-2 text-sm font-semibold">Employees</p>
            <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
              {employees.map((employee) => (
                <label key={employee.id} className="flex cursor-pointer items-center gap-3 rounded-lg border bg-card/50 p-3 text-sm hover:bg-muted/40">
                  <input type="checkbox" checked={employeeIds.includes(employee.id)} onChange={() => toggle(employeeIds, employee.id, setEmployeeIds)} />
                  <span className="font-medium">{employee.fullName}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{employee.department?.name ?? "No dept"}</span>
                </label>
              ))}
            </div>
          </section>
          <section>
            <p className="mb-2 text-sm font-semibold">Trainings</p>
            <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
              {trainings.map((training) => (
                <label key={training.id} className="flex cursor-pointer items-center gap-3 rounded-lg border bg-card/50 p-3 text-sm hover:bg-muted/40">
                  <input type="checkbox" checked={trainingIds.includes(training.id)} onChange={() => toggle(trainingIds, training.id, setTrainingIds)} />
                  <span className="font-medium">{training.title}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{training.category}</span>
                </label>
              ))}
            </div>
          </section>
          <Input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} />
          <Button className="w-full" onClick={assign}><Send className="h-4 w-4" />Assign selected</Button>
        </div>
      </Card>
      <div>
        <h3 className="mb-3 text-sm font-semibold">Current Assignments</h3>
        <DataTable
          data={assignments}
          columns={[
            { key: "employee", label: "Employee", render: (row) => <div><p className="font-semibold">{row.employee.fullName}</p><p className="text-xs text-muted-foreground">{row.employee.employeeCode}</p></div> },
            { key: "training", label: "Training", render: (row) => row.training.title },
            { key: "progressPercent", label: "Progress", render: (row) => `${Math.round(row.progressPercent)}%` },
            { key: "dueDate", label: "Due", render: (row) => row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "No due" },
            {
              key: "status",
              label: "Status",
              render: (row) => {
                const overdue = row.dueDate && new Date(row.dueDate) < new Date() && !row.completedAt;
                const label = overdue ? "OVERDUE" : row.status.replaceAll("_", " ");
                return <Badge tone={overdue || row.status.includes("LATE") ? "red" : row.status.includes("COMPLETED") ? "teal" : "blue"}>{label}</Badge>;
              }
            }
          ]}
        />
      </div>
    </div>
  );
}
