"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import type { Training, TrainingAsset, Assignment } from "@prisma/client";
import { Edit3, Film, Search, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { DataTable } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Input, Textarea } from "@/components/ui/input";
import { trainingSchema } from "@/lib/validation";

type TrainingRow = Training & { assets: TrainingAsset[]; assignments: Assignment[] };
type TrainingInput = z.infer<typeof trainingSchema> & { videoUrl?: string };

const defaults: TrainingInput = {
  title: "",
  description: "",
  category: "General",
  difficulty: "BEGINNER",
  estimatedMinutes: 30,
  dueDate: null,
  thumbnailUrl: "",
  priority: "MEDIUM",
  status: "PUBLISHED",
  tags: [],
  completionCriteria: "WATCH_95_PERCENT",
  videoUrl: ""
};

export function TrainingManager({ initialTrainings }: { initialTrainings: TrainingRow[] }) {
  const [trainings, setTrainings] = useState(initialTrainings);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<TrainingRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<TrainingRow | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const form = useForm<TrainingInput>({
    resolver: zodResolver(trainingSchema.extend({ videoUrl: z.string().url().or(z.string().regex(/^\/uploads\/[\w.-]+$/)).optional().or(z.literal("")) })),
    defaultValues: defaults
  });

  const filtered = useMemo(() => {
    const term = search.toLowerCase();
    return trainings.filter((training) => [training.title, training.category, training.description].some((value) => value.toLowerCase().includes(term)));
  }, [search, trainings]);

  function edit(training: TrainingRow) {
    setEditing(training);
    form.reset({
      title: training.title,
      description: training.description,
      category: training.category,
      difficulty: training.difficulty,
      estimatedMinutes: training.estimatedMinutes,
      dueDate: training.dueDate,
      thumbnailUrl: training.thumbnailUrl ?? "",
      priority: training.priority,
      status: training.status,
      tags: training.tags,
      completionCriteria: training.completionCriteria,
      videoUrl: training.assets[0]?.url ?? ""
    });
  }

  async function save(input: TrainingInput) {
    let videoUrl = input.videoUrl;
    if (videoFile) {
      const upload = new FormData();
      upload.append("file", videoFile);
      const uploadResponse = await fetch("/api/uploads/video", { method: "POST", body: upload });
      if (!uploadResponse.ok) return toast.error("Video upload failed");
      const uploaded = await uploadResponse.json() as { url: string };
      videoUrl = uploaded.url;
    }

    const response = await fetch(editing ? `/api/trainings/${editing.id}` : "/api/trainings", {
      method: editing ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...input, videoUrl })
    });
    if (!response.ok) return toast.error("Training save failed");
    const payload = await response.json() as { training: TrainingRow };
    setTrainings((current) => editing ? current.map((item) => item.id === payload.training.id ? { ...item, ...payload.training } : item) : [payload.training, ...current]);
    setEditing(null);
    setVideoFile(null);
    form.reset(defaults);
    toast.success(editing ? "Training updated" : "Training created");
  }

  async function remove() {
    if (!deleteTarget) return;
    const response = await fetch(`/api/trainings/${deleteTarget.id}`, { method: "DELETE" });
    if (!response.ok) return toast.error("Delete failed");
    setTrainings((current) => current.filter((item) => item.id !== deleteTarget.id));
    setDeleteTarget(null);
    toast.success("Training deleted");
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[0.85fr_1.4fr]">
      <Card>
        <CardHeader>
          <CardTitle>{editing ? "Edit Training" : "Create Training"}</CardTitle>
        </CardHeader>
        <form className="grid gap-3" onSubmit={form.handleSubmit(save)}>
          <Input placeholder="Title" {...form.register("title")} />
          <Textarea placeholder="Description" {...form.register("description")} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Input placeholder="Category" {...form.register("category")} />
            <Input type="number" placeholder="Minutes" {...form.register("estimatedMinutes", { valueAsNumber: true })} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Input type="date" {...form.register("dueDate", { valueAsDate: true })} />
            <select className="h-10 rounded-lg border bg-card px-3 text-sm" {...form.register("priority")}>
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
              <option value="CRITICAL">Critical</option>
            </select>
          </div>
          <Input placeholder="Thumbnail URL" {...form.register("thumbnailUrl")} />
          <Input placeholder="Uploaded, YouTube, or external video URL" {...form.register("videoUrl")} />
          <label className="rounded-lg border border-dashed bg-muted/35 p-3 text-sm">
            <span className="font-medium">Upload MP4/video file</span>
            <input className="mt-2 block w-full text-sm" type="file" accept="video/*" onChange={(event) => setVideoFile(event.target.files?.[0] ?? null)} />
            {videoFile ? <span className="mt-1 block text-xs text-muted-foreground">{videoFile.name}</span> : null}
          </label>
          <div className="flex gap-2">
            <Button className="flex-1"><Film className="h-4 w-4" />{editing ? "Save" : "Create"}</Button>
            {editing ? <Button type="button" variant="secondary" onClick={() => { setEditing(null); form.reset(defaults); }}>Cancel</Button> : null}
          </div>
        </form>
      </Card>
      <div>
        <div className="mb-3 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search trainings..." value={search} onChange={(event) => setSearch(event.target.value)} />
        </div>
        <DataTable
          data={filtered}
          columns={[
            { key: "title", label: "Training", render: (row) => <div><p className="font-semibold">{row.title}</p><p className="text-xs text-muted-foreground">{row.category}</p></div> },
            { key: "dueDate", label: "Due", render: (row) => row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "No due date" },
            { key: "priority", label: "Priority", render: (row) => <Badge tone={row.priority === "CRITICAL" ? "red" : row.priority === "HIGH" ? "amber" : "blue"}>{row.priority}</Badge> },
            { key: "assets", label: "Video", render: (row) => row.assets.length ? <Badge tone="teal">{row.assets[0].type.replace("VIDEO_", "")}</Badge> : <Badge>No video</Badge> },
            { key: "assignments", label: "Assigned", render: (row) => row.assignments.length },
            {
              key: "actions",
              label: "",
              render: (row) => (
                <div className="flex justify-end gap-1">
                  <Button variant="ghost" className="h-9 w-9 px-0" onClick={() => edit(row)}><Edit3 className="h-4 w-4" /></Button>
                  <Button variant="ghost" className="h-9 w-9 px-0" onClick={() => setDeleteTarget(row)}><Trash2 className="h-4 w-4" /></Button>
                </div>
              )
            }
          ]}
        />
      </div>
      <ConfirmDialog open={Boolean(deleteTarget)} title="Delete training?" description="This removes the course, assignments, and progress history for this training." onClose={() => setDeleteTarget(null)} onConfirm={remove} />
    </div>
  );
}
